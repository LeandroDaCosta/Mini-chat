import { StatusBar } from 'expo-status-bar';
import LoginScreen from "./screens/LoginScreen";
import { StyleSheet, Text, View } from 'react-native';
import ChatScreen from "./screens/ChatScreen";
import { createStackNavigator} from 'react-navigation-stack';

const AppNavigator=creatStackNavigator{
  {
    login:LoginScreen,
    chat:ChatScreen
  },

  {
headerMode:"none"
  }
};

export default createAppContainer(AppNavigator);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
